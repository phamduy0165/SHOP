<?php
    if (isset($_SESSION['member']) && isset($_SESSION['member']['username'])) {
        // Lấy thông tin từ mảng $_SESSION['member']
        $username = $_SESSION['member']['username'];
        $query = "SELECT * FROM member WHERE username = '$username'";
        $member = mysqli_fetch_array($connect->query($query));
    }
?>
<?php
    if(isset($_POST['name'])){
        $name=$_POST['name'];
        $mobile=$_POST['mobile'];
        $address=$_POST['address'];
        $email=$_POST['email'];
        $note=$_POST['note'];
        $ordermethodid=$_POST['ordermethodid'];
        $memberid=$member['id'];
        $query="insert orders( ordermethodid, memberid, name, address, mobile, email, note) values( $ordermethodid, $memberid, '$name', '$address', '$mobile', '$email', '$note')";
        $connect->query($query);
        $query="select id from orders order by id desc limit 1";
        $orderid=mysqli_fetch_array($connect->query($query))['id'];
        foreach($_SESSION['cart'] as $key=>$value) {
        $productid=$key;
        $number=$value;
        $query="select discount from products where id=$key";
        $discount=mysqli_fetch_array($connect->query($query))['discount'];
        $query="insert orderdetail values ($productid, $orderid, $number, $discount)";
        $connect->query($query);
        }
        unset($_SESSION['cart']);
        unset($_SESSION['total_items']);
        echo"<script>location='?option=ordersuccess';</script>";
    }
?>
<div class="container">
<h1>ĐẶT HÀNG</h1>
<form method="post">
    <h2>Thông tin người nhận hàng</h2>
    <section>
        <section>
        <label>Họ tên: </label><input name="name" value="<?=$member['username']?>">
        </section>
        <section>
        <label>Điện thoại: </label><input type="tel" name="mobile" value="<?=$member['mobile']?>">
        </section>
        <section>
        <label>Địa chi: </label><textarea name="address" rows="3"></textarea>
        </section>
        <section>
        <label>Email: </label><input type="email" name="email" value="<?=$member['email']?>">
        </section>
        <section>
        <label>Ghi chú: </label><textarea name="note" rows="3"></textarea>
        </section>
    </section>
    <h2>Chọn phương thức thanh toán</h2>
    <?php
        $query="select*from ordermethod where status";
        $result=$connect->query($query);
    ?>
    <select name="ordermethodid">
        <?php foreach($result as $item):?>
            <option value="<?=$item['id']?>"><?=$item['name']?></option>
        <?php endforeach;?>
    </select>
    <section>
        <input type="submit" value="Đặt hàng" style="margin:20px">
    </section>
</form>
</div>
