<section style="text-align: center; font-weight:bold; color: red; margin: 30px 0 450px">
    Bạn đã đặt hàng thành công!<br>Chúng tôi sẽ liên hệ sớm đến bạn.</section>