<?php
    $query_brands="select*from brands where status";
    $result_brands=$connect->query($query_brands);

    $query_prices="select*from prices where status";
    $result_prices=$connect->query($query_prices);
?>
<div class="container">
        <nav class="navbar navbar-expand-lg">                                            
            <div class="row collapse navbar-collapse">
                <ul class="navbar-nav">
                    <li class="col nav-item dropdown">
                        <a class="nav-link text-white" href="?option=mobile">
                        <i class="fa-solid fa-mobile-screen-button icon-large"></i> ĐIỆN THOẠI
                        </a>
                        <div class="dropdown-menu">
                        <div class="dropdown-content">
                            <div class="hang-dien-thoai">                             
                            <a class="dropdown-item" href="#">HÃNG ĐIỆN THOẠI</a>
                            <ul class="dropdown-menu">
                                <?php foreach($result_brands as $item):?>
                                <li>
                                    <a href="?option=showproducts&brandid=<?=$item['id']?>"><?=$item['name']?></a>
                                </li>
                                <?php endforeach;?>
                            </ul>
                            </div>
                            <div class="muc-gia">
                            <a class="dropdown-item" href="#">MỨC GIÁ</a>
                            <ul class="dropdown-menu">
                            <?php foreach($result_prices as $item):?>
                                <li><a href="?option=showproducts&fromprice=<?=$item['fromPrice']?>&toprice=<?=$item['toPrice']?>"><?=$item['pricename']?></a></li>
                            <?php endforeach;?>
                            </ul>
                            </div>
                        </div>
                        </div>
                    </li>
                    <li class="col nav-item dropdown">
                        <a class="nav-link text-white" href="?option=phu-kien">
                            <i class="fa-solid fa-headphones icon-large"></i> PHỤ KIỆN
                        </a>
                        <div class="dropdown-menu">
                        <div class="dropdown-content">
                            <div class="hang-dien-thoai">                             
                            <a class="dropdown-item" href="#">PHỤ KIỆN DI ĐỘNG</a>
                            <ul class="dropdown-menu">
                                <li><a href="">Cáp,sạc</a></li>
                                <li><a href="">Sạc dự phòng</a></li>
                                <li><a href="">Ốp lưng</a></li>
                                <li><a href="">Miếng dán màn hình</a></li>
                                <li><a href="">Hub chuyển đổi</a></li>
                                <li><a href="">Bút cảm ứng</a></li>
                                <li><a href="">Túi đựng AirPods</a></li>
                            </ul>
                            </div>
                            <div class="muc-gia">
                            <a class="dropdown-item" href="#">THIẾT BỊ ÂM THANH</a>
                            <ul class="dropdown-menu">
                                <li><a href="">Tai nghe Bluetooth</a></li>
                                <li><a href="">Tai nghe dây</a></li>
                                <li><a href="">Tai nghe chụp tai</a></li>
                                <li><a href="">Loa Bluetooth</a></li>
                                <li><a href="">Micro</a></li>
                            </ul>
                            </div>
                            <div class="muc-gia">
                            <a class="dropdown-item" href="#">THIẾT BỊ LIVESTREAM</a>
                            <ul class="dropdown-menu">
                                <li><a href="">Camera hành trình</a></li>
                                <li><a href="">Tay cầm chơi game</a></li>
                                <li><a href="">FLycam</a></li>
                                <li><a href="">Tay cầm chống rung</a></li>
                                <li><a href="">Mic thu âm</a></li>
                                <li><a href="">Giá đỡ điện thoại</a></li>
                            </ul>
                            </div>
                        </div>
                        </div>
                    </li>
                    <li class="col nav-item">
                        <a class="nav-link text-white" href="?option=may-cu"><i class="fa-solid fa-arrows-rotate icon-large"></i> MÁY CỦ</a>
                    </li>     
                    <li class="col nav-item">
                        <a class="nav-link text-white" href="?option=sua-chua"><i class="fa-solid fa-screwdriver-wrench"></i> SỬA CHỮA</a>
                    </li>
                    <li class="col nav-item">
                        <a class="nav-link text-white" href="?option=uu-dai"><i class="fa-solid fa-bolt-lightning icon-large"></i> ƯU ĐÃI</a>
                    </li> 
                    <li class="col nav-item">
                        <a class="nav-link text-white" href="?option=tin-moi"><i class="fa-regular fa-newspaper icon-large"></i> TIN MỚI</a>
                    </li>
                    <li class="col nav-item">
                        <a class="nav-link text-white" href="?option=tuyen-dung"><i class="fa-regular fa-bell"></i> TUYỂN DỤNG</a>
                    </li>
                    <li class="col nav-item">
                        <a class="nav-link text-white" href="?option=lien-he"><i class="fa-solid fa-toolbox icon-large"></i> LIÊN HỆ</a>
                    </li>
                </ul>
            </div>                   
        </nav>               
    </div>
