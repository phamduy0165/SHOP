<div class="container">
    <div class="row">
        <div class="col py-4 my-5">[<a href="?option=logout">Đăng xuất</a>]</div>
    </div>
</div>
