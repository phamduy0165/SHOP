<!-- code trang chi tiết sản phẩm -->
<h2>Chi tiết sản phẩm</h2>
<section class="productdetail">
    <section class="img"><img src="images/<?=$item['image']?>"></section>
    <section class="name"><?=$item['name']?></section>
    <section class="price"><?=number_format($item['price'],0,',','.')?>đ</section>
    <section><input type="button" value="Đặt mua" onclick="location='?option=cart&action=add&id=<?=$item['id']?>';"></section>
</section>
<hr>
<section class="description"><?=$item['description']?></section>
<hr>
<section class="comment">
    <h2>Bình luận</h2>
    <form method="post">
        <section>
            <textarea name="content" rows="5" class="form-control" placeholder="Hảy để lại bình luận cho chúng tôi..."></textarea>
            <button type="button" id="checkLoginButton" style="display: none;"></button> </section>
        <section><input type="submit" value="Gửi" class="btn btn-danger"></section>
    </form>
    <?php
        $comments=$connect->query("select*from member a join comment b on a.id=b.memberid join products c on b.productid=c.id where b.status and productid=".$_GET['id']);
        if(mysqli_num_rows($comments)==0):
            echo"<section style='color:green'>No comments!</section>";
        else:
            foreach($comments as $comment):
    ?>
        <section style="font-weight: bold;"><?=$comment['username']?></section>
        <section style="padding-left: 2%"><?=$comment['content']?></section>
    <?php
        endforeach;
        endif;
    ?>
</section>
</div>

<script>
    document.querySelector('textarea[name="content"]').addEventListener('click', function() {
        document.getElementById('checkLoginButton').click();
    });
    document.getElementById('checkLoginButton').addEventListener('click', function() {
    if (!<?php echo json_encode(isset($_SESSION['member'])); ?>) {
        alert('Vui lòng đăng nhập để bình luận.');
        window.location.href = '?option=signin&productid=<?php echo $_GET['id']; ?>';
    }
});
</script>           